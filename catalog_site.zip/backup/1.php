//10
public function getLogoFile10()
{
return $this->logoFile10;
}

public function setLogoFile10(File $file = null): self
{
$this->logoFile10 = $file;

return $this;
}

public function setLogo10($logo10)
{
$this->logo10 = $logo10;
}

public function getLogo10()
{
return $this->logo10;
}

public function getTitle10()
{
return $this->title10;
}

public function setTitle10($title10)
{
$this->title10 = $title10;

return $this;
}

public function getAlt10()
{
return $this->alt10;
}

public function setAlt10($alt10)
{
$this->alt10 = $alt10;

return $this;
}